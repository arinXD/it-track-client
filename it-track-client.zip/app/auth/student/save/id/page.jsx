"use client"
import React, { useState, useEffect } from 'react'
import { Input, Button } from "@nextui-org/react";
import { SubmitButton } from '@/app/components';
const Page = () => {
    const [studentId, setStudentId] = useState("")
    const [isValid, setIsValid] = useState(false)
    const [isSubmit, setIsSubmit] = useState(false)

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(event.target.studentId.value);
        console.log("Form submitted!");
    }

    return (
        <>
            <div className='container my-12 mx-auto'>
                <h1 className='text-2xl font-bold mb-4'>
                    Insert student id
                </h1>
                <form onSubmit={handleSubmit}>
                    <div className="full">
                        <Input
                            id='studentId'
                            value={studentId}
                            onValueChange={setStudentId}
                            isInvalid={isValid}
                            label="รหัสนักศึกษา"
                            size="md"
                            type="text"
                            autoComplete="student id" />
                    </div>
                    <Button
                        {...(isSubmit ? isLoading : null)}
                        type="submit"
                        color="secondary"
                        spinner={
                            <svg
                                className="animate-spin h-5 w-5 text-current"
                                fill="none"
                                viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <circle
                                    className="opacity-25"
                                    cx="12"
                                    cy="12"
                                    r="10"
                                    stroke="currentColor"
                                    strokeWidth="4"
                                />
                                <path
                                    className="opacity-75"
                                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                    fill="currentColor"
                                />
                            </svg>
                        }
                    >
                        {...(isSubmit ? "กำลังโหลด" : "ตกลง")}
                    </Button>
                </form>
            </div>
        </>
    )
}

export default Page