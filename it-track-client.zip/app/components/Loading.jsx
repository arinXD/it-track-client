"use client"
import React from 'react'
import { Spinner } from "@nextui-org/react";

const Loading = () => {
    return (
        <Spinner />
    )
}

export default Loading