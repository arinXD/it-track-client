import PlusIcon from "./PlusIcon"
import EditIcon from "./EditIcon"
import DeleteIcon from "./DeleteIcon"
import EditIcon2 from "./EditIcon2"
import DeleteIcon2 from "./DeleteIcon2"
import SearchIcon from "./SearchIcon"
import VerticalDotsIcon from "./VerticalDotsIcon"
import ChevronDownIcon from "./ChevronDownIcon"
import EyeIcon from "./EyeIcon"
import HomeIcon from "./HomeIcon"
import RightArrow from "./RightArrow"
import ChartPie from "./ChartPie"
import ChartPieBold from "./ChartPieBold"
import CheckIcon from "./CheckIcon"
import ClockIcon from "./ClockIcon"
import ConfirmIcon from "./ConfirmIcon"
export {
    ClockIcon,
    ConfirmIcon,
    CheckIcon,
    ChartPie,
    ChartPieBold,
    RightArrow,
    HomeIcon,
    EyeIcon,
    ChevronDownIcon,
    VerticalDotsIcon,
    SearchIcon,
    PlusIcon,
    DeleteIcon,
    EditIcon,
    DeleteIcon2,
    EditIcon2,
}