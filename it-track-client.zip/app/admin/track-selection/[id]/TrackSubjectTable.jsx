import React from 'react'

const TrackSubjectTable = ({ studentData, track }) => {
    return (
        <></>
    )
}

export default TrackSubjectTable