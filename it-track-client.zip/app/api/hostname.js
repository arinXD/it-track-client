let hostname
hostname = "http://localhost:4000"
// hostname = "https://it-track.arinchawut.com"
module.exports = {
    hostname
}